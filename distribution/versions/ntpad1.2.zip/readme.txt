NTPAD 1.2

For an english version of this text, just read down.

Novedades
---------

- Version 1.2

Instalador hecho a nuevo (de nuevo!!!!!!) para que el driver no se valla
cuando apagas la PC. Ademas, permite sacar el driver directamente desde
joysticks del panel de control y anda perfecto con Windows XP.

Que paso con la dichosa version XP????????
Para varios que se comunicaron con migo (sobretodo los que pedian el soporte
de SNES) la proxima version del driver era la XP. Bueno, eso sigue en pie.
Esta es una simple version intermedia que instala bien de una bendita vez el
driver.

- Versi�n 1.1

Nuevo instalador totalmente autom�tico. Instala solo los dos drivers para soportar
los dos joysticks.

Soporte para dos joysticks

Soporte para LPT2 (autom�tico)

Alg�n avance en el force feedback. Tal vez en la pr�xima versi�n cambie la
metodolog�a del FF y que pase de interpretar las llamadas desde el driver a
interpretarlas desde una DLL que es mucho m�s simple. Por el momento sigue 
sin funcionar. 

- Versiones Anteriores

Desde su primera versi�n hubieron un par que agregaron y mejoraron un poquito
el instalador, pero nada importante.

Instalaci�n
-----------

El programa de instalaci�n instala automaticamente el driver. Solo ejecute
install.
Para reinstalar el driver o actualizarlo, primero quite todos los joysticks
del panel de control.

Configuraci�n
-------------

El driver es "autoconfigurable". Cada vez que va a leer y detecta que el 
joystick no esta instalado en LPT1 prueba en LPT2. 

Uso del joystick
----------------

El driver soporta tanto el digital como el anal�gico. Cuando el anal�gico
se encuentra activado (lease "prendida la lucesita") los direccionales
digitales funcionan como simples botones. Cuando no esta activado o el pad
es solo digital, los direccionales siguen funcionando como botones, pero
tambien establecen la direcci�n :-)

Es recomendable calibrar cuando se utiliza el anal�gico por primera vez.

Force Feedback
--------------

El driver le informa a Windows / DirectX que tiene capacidad de hacer los
efectos Constant Force, Sine y Ramp. El problema es que actualmente no se
como manejar las llamadas PID de USB para hacer que vibre. Si alguien tiene
alguna idea....

Proximas versiones
------------------

En proximas versiones (por lista de prioridades) espero incluir

- Un Logo (sigo esperando alguna idea)
- Soporte para todos los joysticks del DirectPad (necesitaria que alguien
  colaborara prestandome alguno, sobretodo el de N64)


Contacto
--------
Este driver es eMailWare. Usalo todo lo que quieras, pero ya sea para
insultarme por lo mal que anda, te pido que me mandes un mail, ya que quiero
conocer a toda la gente que use mi driver.

Homepage: Se aceptan colaboraciones.....
E-mail: triforce@altavista.net

Son bienvenidas quejas, criticas, problemas, consejos, ayuda psiquiatrica,
etc.

English Version
---------------

News
---------

- Version 1.2

Installer made to new (agin!!!!!!) so the driver does not disapear
when you turn off the PC. Also allows to remove the driver directly from
the joysticks control panel and works perfectly with Windows XP.

What happened with the XP version????????
For all those who got comunicated with me (specially the ones who asked
for the SNES support) the next version of the driver was going to be the XP.
Well, that stills being thruth. This is a simple half version that installs
well the driver.

- Version 1.1

New installer totally automatic. Installs the 2 drivers by it self for get
the support of the 2 joysticks.

Support for 2 joysticks

Support for LPT2 (automatic)

Some advance in the force feedback. Maybe in the next version I change the
method of the FF. It will change from interpreting the FF calls inside the
driver to interpreting from an external DLL witch is much more simplee.
For the moment stills with out working. 

- Later Versions

Since its first version there where a couple who added and got better a
little the installer, but nothing important.

Instalation
-----------

The instalation programs automatically installs the driver. Just run
install.
For reinstalling the driver or actualizate it, first remove all the joysticks
in the control panel.

Configuration
-------------

The driver is "autoconfigurable". Every time that its going to read and
detects that the joystick its not installed in LPT1, tries in LPT2. 

Using the joystick
------------------

The driver supports as the digital as the analog. When the analog its
activated (read "the little light its on") the digital arrows work as simple
buttons. When its not activated or the pad its just digital, the arrows
still working as buttons, but also as directionals :-)

Its recomendated that you calibrate the analog when you are going to use it
for first time.

Force Feedback
--------------

The driver informs to Windows / DirectX that it has the capacity of making
the Constant Force, Sine and Ramp effects. The problem is that for now i don't
know how to handle the PID calls of the USB to make the joystick vibrate. If
any one has an idea.......

Next version
------------

In the next version (by priority list) I hope to add:

- A Logo (I'm still waiting for an idea)
- Support for all the joysticks of the DirectPad (could some one borrow me
  an N64 joystick?)


Contact
-------
This driver is eMailWare. Use it all that you want, but alhought being for
insulting me for my bad working, I ask you that you send me an email, becouse
I wanna meet everbody who uses my driver.

Homepage: Colaborations are accepted.....
E-mail: triforce@altavista.net

There are wellcome complins, critics, problems, recomendatios, psiquiatric
help, etc.


