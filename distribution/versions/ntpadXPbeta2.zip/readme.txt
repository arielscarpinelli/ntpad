NTPAD XP beta 2

For an english version of this text, just read down.

Novedades
---------
- Version XP beta 2

Peque�o error de instalaci�n que no lo instalaba :-))))))

- Version XP beta 1

Mejorado el instalador para cuando el driver esta siendo actualizado de
versiones anteriores. 

Agregada la parte configuracion en el instalador.

Mas velocidad!. Ademas es mas indepedendiente el procesador donde corre, por
lo que deberia detectar siempre cuando el joystick esta conectado (Bug Fix).

Soporte para el pad de SNES.

Soporte para interfaces armadas con una multitap.

Agregada la posibilidad de usar el anal�gico de la derecha como principal
(ejes X, Y) y el de la izquierda como secundario (Z y de rotaci�n Z)

- Version 1.22

VELOCIDAD!!!!!!!!!!!!!!!!!!!!!!!!!!!!!. No mas frameskips cuando usas juegos
emuladores y lo que quieras!!!!!!!!

- Version 1.21

Solucionado el problema "no se encuentra clave del puerto de joystick"
para el instalador sobre XP. Nota: Tal vez sea solo por que tengo nada mas
que un PII 350, pero la instalaci�n en XP se toma sus minutos de "no hacer
nada".

- Version 1.2

Instalador hecho a nuevo (de nuevo!!!!!!) para que el driver no se valla
cuando apagas la PC. Ademas, permite sacar el driver directamente desde
joysticks del panel de control y anda perfecto con Windows XP.

Que paso con la dichosa version XP????????
Para varios que se comunicaron con migo (sobretodo los que pedian el soporte
de SNES) la proxima version del driver era la XP. Bueno, eso sigue en pie.
Esta es una simple version intermedia que instala bien de una bendita vez el
driver.

- Versi�n 1.1

Nuevo instalador totalmente autom�tico. Instala solo los dos drivers para soportar
los dos joysticks.

Soporte para dos joysticks

Soporte para LPT2 (autom�tico)

Alg�n avance en el force feedback. Tal vez en la pr�xima versi�n cambie la
metodolog�a del FF y que pase de interpretar las llamadas desde el driver a
interpretarlas desde una DLL que es mucho m�s simple. Por el momento sigue 
sin funcionar. 

- Versiones Anteriores

Desde su primera versi�n hubieron un par que agregaron y mejoraron un poquito
el instalador, pero nada importante.

Instalaci�n
-----------

El programa de instalaci�n instala automaticamente el driver. Solo ejecute
install.
Para reinstalar el driver o actualizarlo, NO QUITE LOS JOYSTICKS DEL PANEL
DE CONTROL.

Para la gente que no posea un puerto de joystick en la PC estos son los pasos
a seguir:
Simplemente instalen el dispositivo "Puerto de juegos standart" desde Panel
de Control / Agregar nuevo hardware / agregar dispositivo nuevo / manual / 
dispositivos de sonido, video y juegos / dispositivos de sistema standart.
 
Con esto se instala un puerto virtual sobre el cual funciona el driver. 
Lo mismo se aplica para aquellos que quieren utilizar un joystick de puerto de juegos 
ademas del NTPAD.

Configuraci�n
-------------

El driver se configura al momento de la instalaci�n. Ahi hay que elegir
si el driver va a utilizar un pad de PSX en LPT1, en LPT2, uno en una
multitap o uno de SNES.

Tambi�n se puede elegir si se va a usar la palanca de la izquierda o de
la derecha como principal para los pad de PSX.

Se vienen los remapeos de botones.........

Uso del joystick
----------------

El driver soporta tanto el digital como el anal�gico. Cuando el anal�gico
se encuentra activado (lease "prendida la lucesita") los direccionales
digitales funcionan como simples botones. Cuando no esta activado o el pad
es solo digital, los direccionales siguen funcionando como botones, pero
tambien establecen la direcci�n :-)

Es recomendable calibrar cuando se utiliza el anal�gico por primera vez.

Force Feedback
--------------

El driver le informa a Windows / DirectX que tiene capacidad de hacer los
efectos Constant Force, Sine, Ramp y Spring. No se todabia como hacer
el servidor COM para la interfaz IDirectInputEffectDriver. Se aceptan
colaboraciones.

Proximas versiones
------------------

En proximas versiones (por lista de prioridades) espero incluir

- Un Logo (sigo esperando alguna idea)
- Soporte para el joy de N64. No me gusta el de saturn, asi que no pregunten...


Contacto
--------
Este driver es eMailWare. Usalo todo lo que quieras, pero ya sea para
insultarme por lo mal que anda, te pido que me mandes un mail, ya que quiero
conocer a toda la gente que use mi driver.

Homepage: Se aceptan colaboraciones.....
E-mail: triforce@altavista.net

Son bienvenidas quejas, criticas, problemas, consejos, ayuda psiquiatrica,
etc.

English Version
---------------

News
---------
- Version XP beta 2

Little instalation bug who did not install :-))))))

- Version XP beta 1

Better installer for when you are updating the driver from prior versions.

Add the configuration section in the installer.

More speed!. Also is more independat from the processor where is running,
so it should detected allways when the joystick is connected (Bug fix).

Support for the SNES pad.

Support for Multitap based interfaces.

Add the option of using the right analog stick as the main (axes X, Y)
and the left one as secundary (Z and rotation Z)

- Version 1.22

SPEED!!!!!!!!!!!!!!!!!!!!!!!!!!!!!. No more frameskips when you play games
emulators and what ever you want!!!!!!!!

- Version 1.21

Fixed the problem "no se encuentra clave del puerto de joystick" when you
install over XP. Note: Maybe its just because I only have a PII 350, but
the instalation over XP takes its minutes of "doing nothing".

- Version 1.2

Installer made to new (agin!!!!!!) so the driver does not disapear
when you turn off the PC. Also allows to remove the driver directly from
the joysticks control panel and works perfectly with Windows XP.

What happened with the XP version????????
For all those who got comunicated with me (specially the ones who asked
for the SNES support) the next version of the driver was going to be the XP.
Well, that stills being thruth. This is a simple half version that installs
well the driver.

- Version 1.1

New installer totally automatic. Installs the 2 drivers by it self for get
the support of the 2 joysticks.

Support for 2 joysticks

Support for LPT2 (automatic)

Some advance in the force feedback. Maybe in the next version I change the
method of the FF. It will change from interpreting the FF calls inside the
driver to interpreting from an external DLL witch is much more simplee.
For the moment stills with out working. 

- Later Versions

Since its first version there where a couple who added and got better a
little the installer, but nothing important.

Instalation
-----------

The instalation programs automatically installs the driver. Just run
install.
For reinstalling the driver or actualizate it, DO NOT REMOVE the joysticks
in the control panel.
For the people who does not have a gameport in their PC:

Just install the device "Standart Game Port" from  Control Panel /
Add New hardware / Add a new device / manual / sound, video and game
controllers / Standart system devices.
 
With this you install a virtual port where the drivers work on. 
The same applies for those who wants to use a game port joystick
besides the NTPAD

Configuration
-------------

The driver is configurated in the instalation moment. There you have
to choose if the driver is going to use a PSX pad in the LPT1, LPT2,
in a multitap or a SNES pad.

You may also choose if you are going to use the left or the right stick
as the main one for the PSX pad.

Button remappings are comming on......

Using the joystick
------------------

The driver supports as the digital as the analog. When the analog its
activated (read "the little light its on") the digital arrows work as simple
buttons. When its not activated or the pad its just digital, the arrows
still working as buttons, but also as directionals :-)

Its recomendated that you calibrate the analog when you are going to use it
for first time.

Force Feedback
--------------

The driver informs to Windows / DirectX that it has the capacity of making
the Constant Force, Sine, Ramp and Spring effects. I don't know how to make
a COM server for the IDirectInputEffectDriver interface. Any help is
accepted.

Next version
------------

In the next version (by priority list) I hope to add:

- A Logo (I'm still waiting for an idea)
- Support for the N64 joystick. I don't like the saturn one so don't ask...


Contact
-------
This driver is eMailWare. Use it all that you want, but alhought being for
insulting me for my bad working, I ask you that you send me an email, becouse
I wanna meet everbody who uses my driver.

Homepage: Colaborations are accepted.....
E-mail: triforce@altavista.net

There are wellcome complins, critics, problems, recomendatios, psiquiatric
help, etc.


