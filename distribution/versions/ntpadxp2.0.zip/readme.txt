Novedades
---------
- Version XP 2.0

. Agregada hoja de propiedades para el panel de control
. Nuevo instalador
. Viene en 6 idiomas
. Solucionados problemas con soporte de NES y multitap PSX
. Modificado el soporte de FF para que insuma MUCHOS menos recursos.
. Agregados los efectos Damper, Inertia y Friction
. Arreglado el efecto Custom Force
. Arreglado bug en el control de la duracion y repeticion de los efectos
. Solucionados los problemas de cuelgues con EPSXE y ZSNES
. Agregada la opcion para utilizar cualquier puerto
. Agregado control manual de scan delays
. Agregado la opcion de "siempre analogico" sin importar el estado del LED
. Agregado soporte para mapeo de ejes.
. Agregado un nuevo modo de lectura mas fiel a los datos el joystick (mas lento...)


Que es NTPAD?
-------------
NTPAD es un driver que permite utilizar los joysticks de Playstation, PS ONE
Playstation 2, Multitaps Playstation y PS2, Nitendo, Super Nintendo,
Nintendo 64, Sega Genesis, Sega Saturn y Atari / Commodore 64 en la PC
via el puerto paralelo.
El driver es para Windows 2000 y XP. Nada mas. Para Windows 9x existe el
Directpad Pro original.

Soporte
-------
NTPAD Soporta:
- Hasta 2 pads Playstation / PSONE / PSX2 con la interfaz original DirectPad
- Hasta 5 pads Playstation / PSONE / PSX2 con la interfaz MEGATAP o Multitap
- Hasta 4 pads Playstation / PSONE / PSX2 conectando una Multitap como un
  "pad 1".
- Hasta 5 pads Nintendo y Super Nintendo con la interfaz original DirectPad
  o SNESKey
- Hasta 4 pads Nintendo 64 con la interfaz original DirectPad.
- Hasta 1 pad Genesis con la interfaz original DirectPad.
- Hasta 2 pad Genesis con la interfaz nueva. Esta tambi�n funciona en paralelos
  "modernos"
- Hasta 2 pad Saturn con la interfaz original DirectPad.
- Un solo joystick Atari o Commodore 64 con la interfaz original DirectPad.

Instalaci�n y configuraci�n
---------------------------
Para instalar, desinstalar o configurar el driver se tiene el instalador
INSTALL.EXE

Al ingresar en el asistente se puede seleccionar si instalar o desinstalar el
driver. Si se elige desinstalar, el driver y sus archivos se eliminan y se
termina el proceso.
Al elegir instalar se pasa al proceso de configuraci�n.

Primero se debe seleccionar cuantos joysticks soportados por NTPAD se
encuentran instalados (o se van instalar) con un m�ximo de 10 (5 para
cada puerto LPT o puden repetirse...).

Luego se pasa al proceso de configuraci�n de cada pad en particular.

Se debe elegir el tipo de pad que el driver debe controlar para el
disposivo actualmente seleccionado (ej: PAD 1), el puerto en el cual
se encuentra conectado y el ID del pad.

Para pads de playstation se puede configurar ademas el uso del anal�gico
derecho como el principal (ejes X, Y en lugar de Z, Rz), deshabilitar
el forcefeedback y deshabilitar el mapeo de los botones direccionales
para el pad digital (o la alfombra de Dance Dance Revolution por ejeplo),
lo cual permite poder presionar todas la flechas al mismo tiempo.

Tambien se puede seleccionar el nivel de zona muerta el cual permite elegir
hasta que porcentaje desde el centro se toma como si el stick estubiera
centrado (ideal para cuando el joystick ya esta gastado y no se centra bien)

Por ultimo lo tan solicitado, el remapeo de botones. Al apretar en el boton
aparece un cuadro de dialogo con una imagen del joystick seleccionado y que
permite elegir que numero corresponde con cada boton del joystick. Presionando
Reset, el mapeo vuelve al original del driver.

Force Feedback
--------------
El driver soporta los siguientes efectos ForceFeedback:

Constant Force: Emulado por el motor grande. Soporta envelopes y diferentes
                niveles de fuerza.
Ramp Force    : Emulado por el motor grande. Soporta envelopes y diferentes
		niveles de fuerza. Hace la forma de rampa correctamente
Square Force  : Emulado por el motor chico. En EPSXE elegir Sine para el chico
 		y se ejecutara este efecto.
Sine Force    : Emulado por el motor grande. Soporta envelopes y diferentes
		niveles de fuerza. Hace la forma de seno correctamente
Triagle Force : Emulado por el motor grande. Soporta envelopes y diferentes
		niveles de fuerza. Hace la forma de triangulo correctamente
Sawtooth Force: Emulado por el motor grande. Soporta envelopes y diferentes
		niveles de fuerza. Hace la onda correctamente.
Spring Force  : Emulado por el motor chico. Se ejecuta cuando el stick llega
		a 230.
Custom Force  : Emulado por el motor grande. Reproduce los niveles de fuerza
		que el juego indique.

Para los pads PSX/PS1/PS2 en la interfaz "hasta 2 pads", los efectos se
copian de un pad al otro. Esto no pasa en las interfaces "hasta 5 pads"
y "multitap conectado directamente".

La interfaz N64 tambien reproduce los efectos correctamente.

Proximas versiones
------------------

En proximas versiones (por lista de prioridades) espero incluir

- Soporte para GameCube. Para ello es necesario hacer una interfaz y no tengo los
  conocimientos de electronica suficientes as� que les solicito colaboraci�n...

Contacto
--------
Este driver es eMailWare. Usalo todo lo que quieras, pero ya sea para
insultarme por lo mal que anda, te pido que me mandes un mail, ya que quiero
conocer a toda la gente que use mi driver.

Homepage: www.ntpad.com.ar
E-mail: triforce@altavista.net

Son bienvenidas quejas, criticas, problemas, consejos, ayuda psiquiatrica,
etc.

English Version
---------------

News
---------

What is NTPAD?
--------------
NTPAD is a driver that allows you to use the pads of the Playstation, PS ONE
Playstation 2, Multitaps Playstation and PS2, Nitendo, Super Nintendo,
Nintendo 64, Sega Genesis, Sega Saturn y Atari / Commodore 64 in the PC.
by the parallel port.
It is for Windows 2000 y XP. For Windows 9x there is the original
Directpad Pro.

Support
-------
NTPAD Supports:
- Up to 2 pads Playstation / PSONE / PSX2 with the original DirectPad
  interface
- Up to 5 pads Playstation / PSONE / PSX2 with the MEGATAP or Multitap
  interface
- Up to 4 pads Playstation / PSONE / PSX2 by connecting a Multitap like a
  "pad 1".
- Up to 5 pads Nintendo or Super Nintendo with the original DirectPad interface
- Up to 4 pads Nintendo 64 with the original DirectPad interface.
- Up to 1 pad Genesis with the original DirectPad interface.
- Up to 2 pad Genesis with the new interface. This also works with "new"
  parallel ports.
- Up to 2 pad Saturn with the original DirectPad interface.
- One Atari or Commodore joystick with the original DirectPad interface.


Installation and configuration 
------------------------------

In order to install, to uninstall or to configurate the driver you must run INSTALL.EXE.

When entering the wizard it is possible to select if install or uninstall the driver. 
If uninstall is chosen, the driver and their files are eliminated and the process is finished. 

When you choose to install goes to the process of configuration. First, you must select 
how many joysticks supported by NTPAD are installed (or are going to be installed) 
with maximun of 10 (5 for each LPT port or can be repeated...). 

Then you go to the configuration proccess of every pad.

You must select the pad type that the driver should control for the current selected device 
(ex: PAD 1), the port on witch is connected and the pad ID.

For playstation pads you can also configure the using of the right analog
as the main (X, Y axes in place of Z, Rz), disabling the ForceFeedback and
disable the directionals button maping for the digital pad (or the Dance
Dance Revolution carpet...), to allow to press all the directions at the same
time.

You can also select the deathzone level witch allows you to choose how much
percentage from the center is taken as if the stick would be centered.
(perfect for when the joystick is old and doesn't get centered well)

For last the so asked, button remaping. When you select the button remaping button a dialog
box appears with a image of the selected joystick and allows to choose what number corresponds
with every button of the joystick. Pressing Reset, the original driver mapping is restored.

Force Feedback
--------------

The driver supports the following ForceFeedback effects:

Constant Force: Emulated by the big motor. Supports envelopes and differents
                force levels.
Ramp Force    : Emulated by the big motor. Supports envelopes and differents
		force levels. Makes the ramp shape correctly.
Square Force  : Emulado por el motor chico. Choose Sine in EPSXE for the small
 		and this effect will be runed.
Sine Force    : Emulated by the big motor. Supports envelopes and differents
		force levels. Makes the sine wave correctly.
Triagle Force : Emulated by the big motor. Supports envelopes and differents
		force levels. Makes the triangle wave correctly.
Sawtooth Force: Emulated by the big motor. Supports envelopes and differents
		force levels. Makes the wave correctly.
Spring Force  : Emulated by the small motor. Runs when the stick reaches 230.
Custom Force  : Emulated by the big motor. Replays the force levels that the
                game sets.

For the PSX/PS1/PS2 pads in the "up to 2 pads" interface, the effects will
be copied from one pad to the other. This does not happend with the "up
to 5" and "multitap directly connected" interfaces.

N64 interfaces also work correctly.

Next Versions
-------------

In next versions I wish to include

- Support of GameCube pads. For that I need an interface and I don't have the electronics 
  knowlegdments, so colaboration is requested...

Contact
-------
This driver is eMailWare. Use it all that you want, but alhought being for
insulting me for my bad working, I ask you that you send me an email, becouse
I wanna meet everbody who uses my driver.

Homepage: www.ntpad.com.ar
E-mail: triforce@altavista.net

There are wellcome complains, critics, problems, recomendations, psiquiatric
help, etc.


