NTPAD XP Version 1.0

For an english version of this text, just read down.

Novedades
---------
- Version XP 1.0
Novedades:

. Soporte Funcional de ForceFeedback !!!!!!!! (ver mas a bajo en la
  secci�n de FF.
. Soporte de ForceFeedback para PSONE!
. Soporte de ForceFeedback para N64
. Soporte para los puertos LPT3, LPT4 y de NEC
. Lectura por medio de thread separado lo que lo hace mucho m�s veloz y preciso (lee entre
  100 y 500 veces por segundo).
. Solucionados problemas de ejes y botones fantasma para joysticks no PSX.

- Version XP beta 6
Novedades:

. Soporte para los joysticks de N64, Genesis, Saturn y Atari
. Instalador totalmente renovado con formato de asistente y desinstalador
. Soporte hasta 10 joysticks con enumerador propio
  (sin necesidad de un puerto joystick)
. Remapeo de botones
. Mejor respuesta del joystick aumentando el escaneo a 30 veces por segundo
. Opcion "DanceRevolution" que no usa ejes permitiendo apretar todos
  los direccionales al mismo tiempo.


- Version XP beta 5

Menos velocidad limtando la lectura a 23 veces por segundo :-((((((((((
En realidad la diferencia no se nota en FPS pero si en respuesta del joystick.

SOPORTE PARA LOS PAD DE PSONE (deshabilitando el forcefeedback
en el instalador)


- Version XP beta 4

Mas velocidad limitando la lectura a 18 veces por segundo.
No creo poder sacarle mas. Es lo mas acertado de acuerdo con mi analisis
cientifico de "apretar rapido el botoncito" :-).

Solucionados los problemas de lectura del joy de PSX que aparecieron con
la beta 1. Ahora deberia funcionar bien, incluso en maquinas donde el joy
no era detectado con la version 1.22.

Agregado control de deathzone en el instalador. (Se biene el remapeo...)

Grandes avances en ForceFeedback. Si bien no van poder hacer que el joy
vibre con los juegos por ahora, los juegos van a poder detectar e iniciar
la parte del FF.

- Version XP beta 3

Los direccionales de SNES no se mapeaban ejes. Ahora si.

- Version XP beta 2

Peque�o error de instalaci�n que no lo instalaba :-))))))

- Version XP beta 1

Mejorado el instalador para cuando el driver esta siendo actualizado de
versiones anteriores. 

Agregada la parte configuracion en el instalador.

Mas velocidad!. Ademas es mas indepedendiente el procesador donde corre, por
lo que deberia detectar siempre cuando el joystick esta conectado (Bug Fix).

Soporte para el pad de SNES.

Soporte para interfaces armadas con una multitap.

Agregada la posibilidad de usar el anal�gico de la derecha como principal
(ejes X, Y) y el de la izquierda como secundario (Z y de rotaci�n Z)

- Version 1.22

VELOCIDAD!!!!!!!!!!!!!!!!!!!!!!!!!!!!!. No mas frameskips cuando usas juegos
emuladores y lo que quieras!!!!!!!!

- Version 1.21

Solucionado el problema "no se encuentra clave del puerto de joystick"
para el instalador sobre XP. Nota: Tal vez sea solo por que tengo nada mas
que un PII 350, pero la instalaci�n en XP se toma sus minutos de "no hacer
nada".

- Version 1.2

Instalador hecho a nuevo (de nuevo!!!!!!) para que el driver no se valla
cuando apagas la PC. Ademas, permite sacar el driver directamente desde
joysticks del panel de control y anda perfecto con Windows XP.

Que paso con la dichosa version XP????????
Para varios que se comunicaron con migo (sobretodo los que pedian el soporte
de SNES) la proxima version del driver era la XP. Bueno, eso sigue en pie.
Esta es una simple version intermedia que instala bien de una bendita vez el
driver.

- Versi�n 1.1

Nuevo instalador totalmente autom�tico. Instala solo los dos drivers para soportar
los dos joysticks.

Soporte para dos joysticks

Soporte para LPT2 (autom�tico)

Alg�n avance en el force feedback. Tal vez en la pr�xima versi�n cambie la
metodolog�a del FF y que pase de interpretar las llamadas desde el driver a
interpretarlas desde una DLL que es mucho m�s simple. Por el momento sigue 
sin funcionar. 

- Versiones Anteriores

Desde su primera versi�n hubieron un par que agregaron y mejoraron un poquito
el instalador, pero nada importante.

Instalaci�n y configuraci�n
---------------------------
Para instalar, desinstalar o configurar el driver se tiene el instalador
INSTALL.EXE

Al ingresar en el asistente se puede seleccionar si instalar o desinstalar el
driver. Si se elige desinstalar, el driver y sus archivos se eliminan y se
termina el proceso.
Al elegir instalar se pasa al proceso de configuraci�n.

Primero se debe seleccionar cuantos joysticks soportados por NTPAD se
encuentran instalados (o se van instalar) con un m�ximo de 10 (5 para
cada puerto LPT o puden repetirse...).

Luego se pasa al proceso de configuraci�n de cada pad en particular.

Se debe elegir el tipo de pad que el driver debe controlar para el
disposivo actualmente seleccionado (ej: PAD 1), el puerto en el cual
se encuentra conectado y el ID del pad.

Para pads de playstation se puede configurar ademas el uso del anal�gico
derecho como el principal (ejes X, Y en lugar de Z, Rz), deshabilitar
el forcefeedback y deshabilitar el mapeo de los botones direccionales
para el pad digital (o la alfombra de Dance Dance Revolution por ejeplo),
lo cual permite poder presionar todas la flechas al mismo tiempo.

Tambien se puede seleccionar el nivel de zona muerta el cual permite elegir
hasta que porcentaje desde el centro se toma como si el stick estubiera
centrado (ideal para cuando el joystick ya esta gastado y no se centra bien)

Por ultimo lo tan solicitado, el remapeo de botones. Al apretar en el boton
aparece un cuadro de dialogo con una imagen del joystick seleccionado y que
permite elegir que numero corresponde con cada boton del joystick. Presionando
Reset, el mapeo vuelve al original del driver.

Force Feedback
--------------
El driver soporta los siguientes efectos ForceFeedback:

Constant Force: Emulado por el motor grande. Soporta envelopes y diferentes
                niveles de fuerza.
Ramp Force    : Emulado por el motor grande. Soporta envelopes y diferentes
		niveles de fuerza. Hace la forma de rampa correctamente
Square Force  : Emulado por el motor chico. En EPSXE elegir Sine para el chico
 		y se ejecutara este efecto.
Sine Force    : Emulado por el motor grande. Soporta envelopes y diferentes
		niveles de fuerza. Hace la forma de seno correctamente
Triagle Force : Emulado por el motor grande. Soporta envelopes y diferentes
		niveles de fuerza. Hace la forma de triangulo correctamente
Sawtooth Force: Emulado por el motor grande. Soporta envelopes y diferentes
		niveles de fuerza. Hace la onda correctamente.
Spring Force  : Emulado por el motor chico. Se ejecuta cuando el stick llega
		a 230.
Custom Force  : Emulado por el motor grande. Reproduce los niveles de fuerza
		que el juego indique.

Si bien el driver soporta FF en 2 joysticks playstation por individual, ambos joysticks
reproduciran la misma fuerza. Esto se debe a que ambos joysticks reciben infomaci�n
por el mismo canal de datos. Por ello, si me lo piden, puede llegarse a hacer una version
modificada de la interface que envia los datos por separado y agregar una opci�n nueva
al driver. Envienmen emails si les parece necesario esto (y estan dispuestos a modficar
sus interfaces).

Proximas versiones
------------------

En proximas versiones (por lista de prioridades) espero incluir

- Soporte para GameCube. Para ello es necesario hacer una interfaz y no tengo los
  conocimientos de electronica suficientes as� que les solicito colaboraci�n...

Contacto
--------
Este driver es eMailWare. Usalo todo lo que quieras, pero ya sea para
insultarme por lo mal que anda, te pido que me mandes un mail, ya que quiero
conocer a toda la gente que use mi driver.

Homepage: www.ntpad.com.ar
E-mail: triforce@altavista.net

Son bienvenidas quejas, criticas, problemas, consejos, ayuda psiquiatrica,
etc.

English Version
---------------

News
---------
- Version XP beta 7
New developments:

. Funcional ForceFeedback support !!!!!!!! (read down in the FF section)
. PSONE ForceFeedback support!
. N64 ForceFeedback support.
. LPT3, LPT4 and NEC parallel ports support.
. The read is now made by a separated thread who makes it much faster
  and accurate. (reads beetwhen 100 and 500 times per second).
. Solved phantom axes and buttons problems for no PSX pads.

- Version XP beta 6 

New developments: 

. Support for joysticks of N64, Genesis, Saturn and Atari 
. Installer totally renewed with wizard format and uninstaller 
. Support up to 10 joysticks with own enumerador (with no need of a joystick port) 
. Button remaping
. Better answer of joystick increasing the scan to 30 times by second 
. Option " DanceRevolution " that does not use axes allowing to tighten all the 
  directional buttons at the same time. 

- Version XP beta 5

Less speed limiting the read to 23 veces por segundo :-((((((((((
Actually you shouln't note difference in FPS but in joystick response.

SUPPORT FOR PSONE PADS (disabling the forcefeedback
in the installer)

- Version XP beta 4

More speed limiting the read to 18 times per second.
I don't thing that I'll take more off. Its the most accurate acording to 
my cientific analisys "pressing the button quickly".

Fixed the reading problems of the PSX pad whose appeared in beta 1. 
Now it should work well, even in machines where the pad wasn't detected 
with version 1.22.

Added deathzone control in the installer. (Remap is comming...)

Big improvents with ForceFeedback. You won't be able to make the pad
vibrate with the games for the moment, but they will detect and start the FF.

- Version XP beta 3

The SNES directionals were not mapped as axes. Now do.

- Version XP beta 2

Little instalation bug who did not install :-))))))

- Version XP beta 1

Better installer for when you are updating the driver from prior versions.

Add the configuration section in the installer.

More speed!. Also is more independat from the processor where is running,
so it should detected allways when the joystick is connected (Bug fix).

Support for the SNES pad.

Support for Multitap based interfaces.

Add the option of using the right analog stick as the main (axes X, Y)
and the left one as secundary (Z and rotation Z)

- Version 1.22

SPEED!!!!!!!!!!!!!!!!!!!!!!!!!!!!!. No more frameskips when you play games
emulators and what ever you want!!!!!!!!

- Version 1.21

Fixed the problem "no se encuentra clave del puerto de joystick" when you
install over XP. Note: Maybe its just because I only have a PII 350, but
the instalation over XP takes its minutes of "doing nothing".

- Version 1.2

Installer made to new (agin!!!!!!) so the driver does not disapear
when you turn off the PC. Also allows to remove the driver directly from
the joysticks control panel and works perfectly with Windows XP.

What happened with the XP version????????
For all those who got comunicated with me (specially the ones who asked
for the SNES support) the next version of the driver was going to be the XP.
Well, that stills being thruth. This is a simple half version that installs
well the driver.

- Version 1.1

New installer totally automatic. Installs the 2 drivers by it self for get
the support of the 2 joysticks.

Support for 2 joysticks

Support for LPT2 (automatic)

Some advance in the force feedback. Maybe in the next version I change the
method of the FF. It will change from interpreting the FF calls inside the
driver to interpreting from an external DLL witch is much more simplee.
For the moment stills with out working. 

- Later Versions

Since its first version there where a couple who added and got better a
little the installer, but nothing important.

Installation and configuration 
------------------------------

In order to install, to uninstall or to configurate the driver you must run INSTALL.EXE.

When entering the wizard it is possible to select if install or uninstall the driver. 
If uninstall is chosen, the driver and their files are eliminated and the process is finished. 

When you choose to install goes to the process of configuration. First, you must select 
how many joysticks supported by NTPAD are installed (or are going to be installed) 
with maximun of 10 (5 for each LPT port or can be repeated...). 

Then you go to the configuration proccess of every pad.

You must select the pad type that the driver should control for the current selected device 
(ex: PAD 1), the port on witch is connected and the pad ID.

For playstation pads you can also configure the using of the right analog
as the main (X, Y axes in place of Z, Rz), disabling the ForceFeedback and
disable the directionals button maping for the digital pad (or the Dance
Dance Revolution carpet...), to allow to press all the directions at the same
time.

You can also select the deathzone level witch allows you to choose how much
percentage from the center is taken as if the stick would be centered.
(perfect for when the joystick is old and doesn't get centered well)

For last the so asked, button remaping. When you select the button remaping button a dialog
box appears with a image of the selected joystick and allows to choose what number corresponds
with every button of the joystick. Pressing Reset, the original driver mapping is restored.

Force Feedback
--------------

The driver supports the following ForceFeedback effects:

Constant Force: Emulated by the big motor. Supports envelopes and differents
                force levels.
Ramp Force    : Emulated by the big motor. Supports envelopes and differents
		force levels. Makes the ramp shape correctly.
Square Force  : Emulado por el motor chico. Choose Sine in EPSXE for the small
 		and this effect will be runed.
Sine Force    : Emulated by the big motor. Supports envelopes and differents
		force levels. Makes the sine wave correctly.
Triagle Force : Emulated by the big motor. Supports envelopes and differents
		force levels. Makes the triangle wave correctly.
Sawtooth Force: Emulated by the big motor. Supports envelopes and differents
		force levels. Makes the wave correctly.
Spring Force  : Emulated by the small motor. Runs when the stick reaches 230.
Custom Force  : Emulated by the big motor. Replays the force levels that the
                game sets.

The driver supports FF in both playstation joysticks individualy, but both joysticks
will play the same force. That's because both joysticks get the information from the
same data channel. That's why, if you ask me for, I could make a modified version of
the interface that sends the data separatly and add a new option to the driver. Send
me emails if you thing that this is neccesary (and you want to modify your interfaces).

Next Versions
-------------

In next versions I wish to include

- Support of GameCube pads. For that I need an interface and I don't have the electronics 
  knowlegdments, so colaboration is requested...

Contact
-------
This driver is eMailWare. Use it all that you want, but alhought being for
insulting me for my bad working, I ask you that you send me an email, becouse
I wanna meet everbody who uses my driver.

Homepage: www.ntpad.com.ar
E-mail: triforce@altavista.net

There are wellcome complains, critics, problems, recomendations, psiquiatric
help, etc.


